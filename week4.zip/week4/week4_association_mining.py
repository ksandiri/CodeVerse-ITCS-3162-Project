"""
Week 4 - Model Creation & Association Mining
Deliverable 4: End-to-End Association Pipeline (Python equivalent of the KNIME workflow)

KNIME node          ->  Python step
-------------------------------------------------------------
Association Rule Learner (Borgelt)  ->  Apriori frequent itemsets + association_rules (mlxtend)
Row Filter                          ->  boolean masks on the rules DataFrame
Sorter                              ->  DataFrame.sort_values

Input : outputs/week3/boolean_feature_matrix.csv  (14,999 x 34 of 0/1)
Output: outputs/week4/*.csv

Run:  python week4_association_mining.py
      python week4_association_mining.py --min-support 0.05 --min-confidence 0.7
"""
import argparse
import os
import re
import sys

import pandas as pd
from mlxtend.frequent_patterns import apriori, association_rules

# ----------------------------------------------------------------------------
# Configuration (defaults; override on the command line)
# ----------------------------------------------------------------------------
INPUT_PATH = os.path.join("outputs", "week3", "boolean_feature_matrix.csv")
BINNED_PATH = os.path.join("outputs", "week3", "cleaned_binned_dataset.csv")
OUTPUT_DIR = os.path.join("outputs", "week4")

MIN_SUPPORT = 0.05       # itemset must appear in >= 5% of rows
MIN_CONFIDENCE = 0.60    # rule must hold >= 60% of the time
MAX_ITEMSET_LEN = 4      # Borgelt "max rule length" equivalent
MIN_LIFT = 1.0           # Row Filter: keep positively associated rules only
TARGET_MIN_CONFIDENCE = 0.35  # lower bar for the rare outcome LeftCompany=Yes (~24% base rate)
TARGET_MIN_LIFT = 1.3         # ...but require a clear lift over the base rate

FEATURES = [
    "SatisfactionLevel", "LastEvaluation", "NumberProject",
    "AverageMonthlyHours", "TimeSpendCompany", "WorkAccident",
    "LeftCompany", "PromotionLast5years", "Department", "Salary",
]


# ----------------------------------------------------------------------------
# Step 1: Load the Boolean matrix
# ----------------------------------------------------------------------------
def load_boolean_matrix(path: str) -> pd.DataFrame:
    """Load the Week 3 one-hot matrix; rebuild it from the binned file if missing."""
    if os.path.exists(path):
        df = pd.read_csv(path)
    elif os.path.exists(BINNED_PATH):
        print(f"[info] {path} not found - rebuilding from {BINNED_PATH}")
        binned = pd.read_csv(BINNED_PATH)
        df = pd.get_dummies(binned[FEATURES].astype(str), prefix_sep="_")
    else:
        sys.exit(f"[error] Could not find {path} or {BINNED_PATH}. Run week3_binning.py first.")

    # Coerce to boolean and drop any non 0/1 columns (e.g. an ID column)
    keep = [c for c in df.columns if set(df[c].dropna().unique()) <= {0, 1, True, False}]
    dropped = set(df.columns) - set(keep)
    if dropped:
        print(f"[info] Dropped non-boolean columns: {sorted(dropped)}")
    return df[keep].astype(bool)


def feature_of(item: str) -> str:
    """Map an item such as 'SatisfactionLevel_Low' or 'Salary=high' to its source feature."""
    for f in FEATURES:
        if re.match(rf"^{re.escape(f)}[_=: ]", item, flags=re.IGNORECASE):
            return f
    return item.split("_")[0]


def fmt(itemset) -> str:
    return " AND ".join(sorted(itemset))


# ----------------------------------------------------------------------------
# Step 2: Association Rule Learner (Borgelt equivalent)
# ----------------------------------------------------------------------------
def learn_rules(bool_df, min_support, min_confidence, max_len):
    itemsets = apriori(bool_df, min_support=min_support, use_colnames=True, max_len=max_len)
    itemsets["length"] = itemsets["itemsets"].apply(len)
    print(f"[learner] {len(itemsets):,} frequent itemsets (support >= {min_support})")

    rules = association_rules(itemsets, metric="confidence", min_threshold=min_confidence)
    print(f"[learner] {len(rules):,} rules (confidence >= {min_confidence})")
    return itemsets, rules


# ----------------------------------------------------------------------------
# Step 3: Row Filter
# ----------------------------------------------------------------------------
def remove_same_feature_rules(rules: pd.DataFrame) -> pd.DataFrame:
    """Drop rules where antecedent and consequent share an original feature
    (e.g. a 'one hot' sibling like Salary_low -> Salary_high is trivial)."""
    def clean(row):
        a = {feature_of(i) for i in row["antecedents"]}
        c = {feature_of(i) for i in row["consequents"]}
        return a.isdisjoint(c)
    return rules[rules.apply(clean, axis=1)]


def row_filter(rules, min_lift, single_consequent=True):
    f = rules[rules["lift"] >= min_lift]
    if single_consequent:
        f = f[f["consequents"].apply(len) == 1]
    return remove_same_feature_rules(f)


def consequent_filter(rules, item_substrings):
    """Keep rules whose consequent contains any of the given substrings (case-insensitive)."""
    pat = "|".join(re.escape(s.lower()) for s in item_substrings)
    mask = rules["consequents"].apply(lambda s: bool(re.search(pat, fmt(s).lower())))
    return rules[mask]


# ----------------------------------------------------------------------------
# Step 4: Sorter
# ----------------------------------------------------------------------------
def sorter(rules, by=("lift", "confidence", "support")):
    return rules.sort_values(list(by), ascending=False).reset_index(drop=True)


# ----------------------------------------------------------------------------
# Output helpers
# ----------------------------------------------------------------------------
def to_readable(rules: pd.DataFrame) -> pd.DataFrame:
    out = pd.DataFrame({
        "antecedent": rules["antecedents"].apply(fmt),
        "consequent": rules["consequents"].apply(fmt),
        "support": rules["support"].round(4),
        "confidence": rules["confidence"].round(4),
        "lift": rules["lift"].round(4),
        "leverage": rules["leverage"].round(4),
        "conviction": rules["conviction"].replace([float("inf")], 999.0).round(4),
        "antecedent_support": rules["antecedent support"].round(4),
        "consequent_support": rules["consequent support"].round(4),
    })
    out.insert(0, "rule", out["antecedent"] + "  =>  " + out["consequent"])
    return out


def main():
    p = argparse.ArgumentParser(description="Week 4 association rule mining")
    p.add_argument("--input", default=INPUT_PATH)
    p.add_argument("--output-dir", default=OUTPUT_DIR)
    p.add_argument("--min-support", type=float, default=MIN_SUPPORT)
    p.add_argument("--min-confidence", type=float, default=MIN_CONFIDENCE)
    p.add_argument("--max-len", type=int, default=MAX_ITEMSET_LEN)
    p.add_argument("--min-lift", type=float, default=MIN_LIFT)
    p.add_argument("--target-confidence", type=float, default=TARGET_MIN_CONFIDENCE)
    p.add_argument("--target-lift", type=float, default=TARGET_MIN_LIFT)
    p.add_argument("--top", type=int, default=15, help="rows to print per table")
    args = p.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)

    bool_df = load_boolean_matrix(args.input)
    print(f"[load] matrix shape: {bool_df.shape}")

    itemsets, rules = learn_rules(bool_df, args.min_support, args.min_confidence, args.max_len)
    if rules.empty:
        sys.exit("[warn] No rules found. Lower --min-support or --min-confidence.")

    # ---- Row Filter + Sorter -------------------------------------------------
    filtered = row_filter(rules, args.min_lift)
    print(f"[filter ] {len(filtered):,} rules after lift >= {args.min_lift}, single consequent, "
          f"no same-feature rules")
    final = sorter(filtered)

    # Focused views for the project's business question (attrition / satisfaction / promotion)
    # Attrition is a minority class, so it gets its own thresholds (second Learner pass
    # on the same frequent itemsets with a lower confidence bar, then Row Filter + Sorter).
    t_rules = association_rules(itemsets, metric="confidence", min_threshold=args.target_confidence)
    t_rules = row_filter(t_rules, args.target_lift)
    attrition_yes = sorter(consequent_filter(t_rules, ["LeftCompany_Yes", "LeftCompany=Yes",
                                                        "LeftCompany_1"]))
    attrition_no = sorter(consequent_filter(final, ["LeftCompany_No", "LeftCompany=No",
                                                     "LeftCompany_0"]))
    satisfaction = sorter(consequent_filter(final, ["SatisfactionLevel"]))

    # ---- Save ---------------------------------------------------------------
    it_out = itemsets.copy()
    it_out["itemsets"] = it_out["itemsets"].apply(fmt)
    it_out.sort_values("support", ascending=False).to_csv(
        os.path.join(args.output_dir, "frequent_itemsets.csv"), index=False)

    to_readable(rules).to_csv(os.path.join(args.output_dir, "all_rules_unfiltered.csv"), index=False)
    to_readable(final).to_csv(os.path.join(args.output_dir, "association_rules_filtered_sorted.csv"), index=False)
    to_readable(attrition_yes).to_csv(os.path.join(args.output_dir, "rules_predicting_attrition.csv"), index=False)
    to_readable(attrition_no).to_csv(os.path.join(args.output_dir, "rules_predicting_retention.csv"), index=False)
    to_readable(satisfaction).to_csv(os.path.join(args.output_dir, "rules_predicting_satisfaction.csv"), index=False)

    summary = pd.DataFrame([
        ("input_rows", len(bool_df)), ("input_items", bool_df.shape[1]),
        ("min_support", args.min_support), ("min_confidence", args.min_confidence),
        ("max_itemset_length", args.max_len), ("min_lift_filter", args.min_lift),
        ("frequent_itemsets", len(itemsets)), ("rules_before_filter", len(rules)),
        ("rules_after_filter", len(final)),
        ("rules_predicting_attrition", len(attrition_yes)),
        ("rules_predicting_retention", len(attrition_no)),
        ("rules_predicting_satisfaction", len(satisfaction)),
    ], columns=["metric", "value"]).astype({"value": object})
    summary.to_csv(os.path.join(args.output_dir, "pipeline_summary.csv"), index=False)

    # ---- Console report -----------------------------------------------------
    pd.set_option("display.width", 220, "display.max_colwidth", 90)
    cols = ["rule", "support", "confidence", "lift"]
    for title, tbl in [("TOP RULES (sorted by lift)", final),
                       (f"TOP RULES PREDICTING ATTRITION (conf >= {args.target_confidence}, lift >= {args.target_lift})", attrition_yes),
                       ("TOP RULES PREDICTING SATISFACTION", satisfaction)]:
        print(f"\n=== {title} ===")
        r = to_readable(tbl)
        print(r[cols].head(args.top).to_string(index=False) if len(r) else "(none at these thresholds)")

    print(f"\n[done] Outputs written to {args.output_dir}/")


if __name__ == "__main__":
    main()
